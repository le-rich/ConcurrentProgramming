defmodule Broadcast do
  @moduledoc """
  Documentation for `Broadcast`.
  """

  @doc """
  Hello world.

  ## Examples

      iex> Broadcast.hello()
      :world

  """
  def hello do
    :world
  end
end
