defmodule Weather do
  @moduledoc """
  Documentation for `Weather`.
  """

  @doc """
  Hello world.

  ## Examples

      iex> Weather.hello()
      :world

  """
  def hello do
    :world
  end
end
