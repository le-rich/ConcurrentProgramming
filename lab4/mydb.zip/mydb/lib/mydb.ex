defmodule Mydb do
  @moduledoc """
  Documentation for `Mydb`.
  """

  @doc """
  Hello world.

  ## Examples

      iex> Mydb.hello()
      :world

  """
  def hello do
    :world
  end
end
