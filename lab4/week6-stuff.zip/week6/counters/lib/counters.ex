defmodule Counters do
  @moduledoc """
  Documentation for `Counters`.
  """

  @doc """
  Hello world.

  ## Examples

      iex> Counters.hello()
      :world

  """
  def hello do
    :world
  end
end
